"use strict";

var _require = require('raia'),
    Window = _require.Window;

var window = new Window("title", 800, 600);

window.onUpdate(function () {
    window.setCurrentColor(0, 0, 0, 255);
    window.drawFilledRect(0, 0, 800, 600);
    window.redraw();
});