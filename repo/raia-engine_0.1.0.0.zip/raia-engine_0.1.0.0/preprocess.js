// preprocess.js
//
// This script file is for pre-processing the programme before running it. Do not modify or delete it.
// このスクリプトファイルはプログラムを実行する前に事前処理をするためのものです。変更したり削除したりしないでください。

__Raia__.es6_mode = false; // ES6モード。ES6ファイルを優先的に探してトランスコンパイルしてから実行する
__Raia__.allDirectories = undefined; // 実行ファイルがあるディレクトリ内の子ディレクトリを含むすべてのディレクトリ
__Raia__.babel = undefined; // babelオブジェクト

(function () {
    // 指定したパスにあるすべてのディレクトリを取得する
    function getDirectories(path) {
        return __Raia__.Core.IO.getDirectories(path);
    };

    // 再帰的に階層となっている子ディレクトリを含むすべてのディレクトリを取得する
    function getDirectoriesRecursively(path) {
        var allDirectories = [];
        var directories = getDirectories(path);
        directories.forEach(function(directory) {
            var fullPath = path + '/' + directory;
            allDirectories.push(fullPath);
            var childDirectories = getDirectoriesRecursively(fullPath);
            allDirectories = allDirectories.concat(childDirectories);
        });
        return allDirectories;
    };

    // すべてのディレクトリ情報を取得・格納する
    __Raia__.allDirectories = getDirectoriesRecursively(__Raia__.Core.IO.getCurrentPath());
    __Raia__.allDirectories.unshift('.');
    __Raia__.allDirectories.unshift(__Raia__.Core.IO.getCurrentPath());

    // startup.es6とmodules/babel.jsがあったらES6モードをtrueにする
    if ((__Raia__.Core.IO.checkPath(__Raia__.Core.IO.getCurrentPath() + '/startup.es6') === 1) &&
        __Raia__.Core.IO.checkPath(__Raia__.Core.IO.getCurrentPath() + '/modules/babel.js')) {
        //__Raia__.es6_mode = true;
    }
}());

Duktape.modSearch = function (path, require, exports, module) {
    function replaceLast(str, search, replacement) {
        var lastIndex = str.lastIndexOf(search);
        if (lastIndex === -1) {
            return str;
        }
        return str.slice(0, lastIndex) + replacement + str.slice(lastIndex + search.length);
    }
    var new_path = '';
    var es6 = __Raia__.es6_mode;
    var isCurrentModule = false;
    if (__Raia__.Core.IO.checkPath(path) === 1) {
        new_path = path;
    } else if (__Raia__.Core.IO.checkPath(path) === 2) {
        if ((__Raia__.Core.IO.checkPath(path + '/index.es6') === 1) && (es6 === true)) {
            new_path = path + '/index.es6';
            isCurrentModule = true;
        } else {
            new_path = path + '/index.js';
        }
    } else if ((__Raia__.Core.IO.checkPath(path + '.es6') === 1) && (es6 === true)) {
        new_path = path + '.es6';
        isCurrentModule = true;
    } else if (__Raia__.Core.IO.checkPath(path + '.js') === 1) {
        new_path = path + '.js';
    } else if (__Raia__.Core.IO.checkPath('modules/' + path) === 1) {
        new_path = 'modules/' + path;
    } else if (__Raia__.Core.IO.checkPath('modules/' + path) === 2) {
        if ((__Raia__.Core.IO.checkPath('modules/' + path + '/index.es6') === 1) && (es6 === true)) {
            new_path = 'modules/' + path + '/index.es6';
            isCurrentModule = true;
        } else {
            new_path = 'modules/' + path + '/index.js';
        }
    } else if ((__Raia__.Core.IO.checkPath('modules/' +path + '.es6') === 1) && (es6 === true)) {
        new_path = 'modules/' + path + '.es6';
        isCurrentModule = true;
    } else if (__Raia__.Core.IO.checkPath('modules/' +path + '.js') === 1) {
        new_path = 'modules/' + path + '.js';
    } else {
        for (var i = 0; i < __Raia__.allDirectories.length; i++) {
            if (__Raia__.Core.IO.checkPath(__Raia__.allDirectories[i] + '/' + path) === 1) {
                new_path = __Raia__.allDirectories[i] + '/' + path;
                break;
            } else if (__Raia__.Core.IO.checkPath(__Raia__.allDirectories[i] + '/' + path) === 2) {
                if ((__Raia__.Core.IO.checkPath(__Raia__.allDirectories[i] + '/' + path + '/index.es6') === 1) && (es6 === true)) {
                    new_path = __Raia__.allDirectories[i] + '/' + path + '/index.es6';
                    isCurrentModule = true;
                } else {
                    new_path = __Raia__.allDirectories[i] + '/' + path + '/index.js';
                }
                break;
            } else if ((__Raia__.Core.IO.checkPath(__Raia__.allDirectories[i] + '/' + path + '.es6') === 1) && (es6 === true)) {
                new_path = __Raia__.allDirectories[i] + '/' + path + '.es6';
                isCurrentModule = true;
                break;
            } else if (__Raia__.Core.IO.checkPath(__Raia__.allDirectories[i] + '/' + path + '.js') === 1) {
                new_path = __Raia__.allDirectories[i] + '/' + path + '.js';
                break;
            }
        }
    }
    var ret = __Raia__.Core.IO.loadStringFilename(new_path);
    if (typeof ret !== 'string') {
        throw new Error('module not found: ' + id);
    }
    if ((es6 === true) && (isCurrentModule === true) && (typeof __Raia__.babel !== 'undefined')) {
        var code = ret;//__Raia__.Core.IO.loadStringFilename(new_path);
        var options = {presets: ['es2015']}; // or es2015, es2016, es2017, latest
        var result = __Raia__.babel.transform(code, options, function(err, result) {
             return result.code;
        });
        var replaced_path = replaceLast(new_path, '.es6', '.js');
        var check = __Raia__.Core.IO.writeStringFilename(replaced_path, result.code);
        if (check !== 0) {
            throw new Error('Failed to write file. File Name: ' + replaced_path);
        }
        ret = result.code;
    }
    return ret;
};

(function () {
    if (__Raia__.es6_mode === true) {
        __Raia__.babel = require('babel'); // 6.26.0
    } else {
        return;
    }
    var code = __Raia__.Core.IO.loadStringFilename(__Raia__.Core.IO.getCurrentPath() + '/startup.es6');
    var options = {presets: ['es2015']}; // or es2015, es2016, es2017, latest
    var result = __Raia__.babel.transform(code, options, function(err, result) {
        return result.code;
    });
    var ret = __Raia__.Core.IO.writeStringFilename(__Raia__.Core.IO.getCurrentPath() + '/startup.js', result.code);
    if (ret !== 0) {
        throw new Error('Failed to write file. File Name: ' + __Raia__.Core.IO.getCurrentPath() + '/startup.js');
    }
}());